/** Unique ioctl commands supported by irpipe. */

#define LIRC_SET_FEATURES   _IOW('i', 0x00000040, __u32)
#define LIRC_SET_LENGTH     _IOW('i', 0x00000041, __u32)
